# -*- coding: utf-8 -*-
import os
import sys
import subprocess as sp
import shutil
import socket

repos="syliu/qc"
version="latest"
cwd = os.getcwd()
disk = cwd.split('\\')[0]
pwd = cwd.replace('\\','/')
QC_dir = disk + '/QC'
logo_dir=QC_dir + '/logo'
doc_data_dir="/host"
doc_log_dir="/home/log"
usr = os.getenv('username')
desk_icon=disk + '/Users/' + usr + '/Desktop/QC.exe'
log_dir=QC_dir + "/log"
log_file=log_dir + '/result.log'

def get_host_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', 80))
        ip = s.getsockname()[0]
    finally:
        s.close()
    return ip

if not os.path.exists(QC_dir):
    os.mkdir(QC_dir)
    
if not os.path.exists(log_dir):
    os.mkdir(log_dir)
    with open(log_file, 'w') as f:
        f.close()
    
#if not os.path.exists(logo_dir):
#    os.mkdir(logo_dir)
#    shutil.copyfile(pwd + '/logo.png', logo_dir + '/logo.png')

imgs = sp.getoutput('docker images')
if repos not in imgs:
    os.system('docker pull ' + repos + ':' + version)

localIP = get_host_ip()

ctns = sp.getoutput('docker ps -a')
if 'QC' not in ctns:
    os.system('docker run -it -d --name=QC -e DISPLAY=' + localIP + ':0.0 -v ' + '/:' + doc_data_dir + ' ' + repos + ':' + version + ' /bin/bash /home/run_QC/run_QC.sh')
else:
    os.system('docker stop QC')
    os.system('docker rm QC')
    os.system('docker run -it -d --name=QC -e DISPLAY=' + localIP + ':0.0 -v ' + '/:' + doc_data_dir + ' ' + repos + ':' + version + ' /bin/bash /home/run_QC/run_QC.sh')

shutil.copyfile(pwd + '/QC.exe', desk_icon)
shutil.copyfile(pwd + '/QC.exe', QC_dir)
