#!/bin/bash -l
xhost +
echo running QC script
res=`docker ps`
strQC="QC_GPU"
if [[ $res == *$strQC* ]]
then
echo stop old docker session
docker stop QC_GPU
echo start new docker session
docker start QC_GPU
else
echo start new docker session
docker start QC_GPU
fi
echo entering docker
docker exec --runtime=nvidia -it QC_GPU /bin/bash /home/run_QC/run_QC.sh
