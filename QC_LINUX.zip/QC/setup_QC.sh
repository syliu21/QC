#!/bin/bash

repos="syliu/qc"
version="latest"
QC_dir="/home/$USER/QC"
logo_dir="/home/$USER/QC/logo"
doc_data_dir="/host"
doc_log_dir="/home/log"
desk_icon_CPU="/home/$USER/Desktop/QC_CPU.desktop"
desk_icon_GPU="/home/$USER/Desktop/QC_GPU.desktop"
log_dir_CPU="/home/$USER/QC/log_CPU"
log_dir_GPU="/home/$USER/QC/log_GPU"
QC_shell_CPU="/home/$USER/QC/run_QC_CPU.sh"
QC_shell_GPU="/home/$USER/QC/run_QC_GPU.sh"

if [ ! -d "$QC_dir" ]; then
mkdir "$QC_dir"
else
rm -rf $QC_dir
mkdir "$QC_dir"
fi

if [ ! -d "$logo_dir" ]; then
mkdir "$logo_dir"
cd "$logo_dir"
cp "/home/$USER/Desktop/QC/logo/logo.png" "/home/$USER/QC/logo/"
fi

if [ ! -f $QC_shell_CPU ]; then
touch "$QC_shell_CPU"
fi

if [ ! -f $QC_shell_GPU ]; then
touch "$QC_shell_GPU"
fi

if [ ! -f "$desk_icon_CPU" ]; then
touch "$desk_icon_CPU"
else
rm -f $desk_icon_CPU
touch "$desk_icon_CPU"
fi

if [ ! -f "$desk_icon_GPU" ]; then
touch "$desk_icon_GPU"
else
rm -f $desk_icon_GPU
touch "$desk_icon_GPU"
fi

imgs=`docker images` 
ctns=`docker ps -a`
strQC_CPU="QC_CPU"
strQC_GPU="QC_GPU"
if [[ $imgs != *$repos* ]]; then
docker pull "$repos":"$version"
elif [[ $ctns == *$strQC_CPU* ]]; then
docker stop QC_CPU
docker rm QC_CPU
docker rmi "$repos":"$version"
docker pull "$repos":"$version"
elif [[ $ctns == *$strQC_GPU* ]]; then
docker stop QC_GPU
docker rm QC_GPU
docker rmi "$repos":"$version"
docker pull "$repos":"$version"
fi

if [[ $ctns != *$strQC_CPU* ]]; then
docker run -d --name=QC_CPU -v /tmp/.X11-unix:/tmp/.X11-unix -e DISPLAY=unix$DISPLAY -v /:"$doc_data_dir" -v "$log_dir_CPU":"$doc_log_dir" "$repos":"$version" /bin/bash /home/run_QC/run_QC.sh
else
docker stop QC_CPU
docker rm QC_CPU
docker run -d --name=QC_CPU -v /tmp/.X11-unix:/tmp/.X11-unix -e DISPLAY=unix$DISPLAY -v /:"$doc_data_dir" -v "$log_dir_CPU":"$doc_log_dir" "$repos":"$version" /bin/bash /home/run_QC/run_QC.sh
fi

if [[ $ctns != *$strQC_GPU* ]]; then
docker run --runtime=nvidia -d --name=QC_GPU -v /tmp/.X11-unix:/tmp/.X11-unix -e DISPLAY=unix$DISPLAY -v /:"$doc_data_dir" -v "$log_dir_GPU":"$doc_log_dir" "$repos":"$version" /bin/bash /home/run_QC/run_QC.sh
else
docker stop QC_GPU
docker rm QC_GPU
docker run --runtime=nvidia -d --name=QC_GPU -v /tmp/.X11-unix:/tmp/.X11-unix -e DISPLAY=unix$DISPLAY -v /:"$doc_data_dir" -v "$log_dir_GPU":"$doc_log_dir" "$repos":"$version" /bin/bash /home/run_QC/run_QC.sh
fi

cp "/home/$USER/Desktop/QC/run_QC_CPU.sh" "/home/$USER/QC/run_QC_CPU.sh"
cp "/home/$USER/Desktop/QC/run_QC_GPU.sh" "/home/$USER/QC/run_QC_GPU.sh"
cp "/home/$USER/Desktop/QC/QC_CPU.desktop" "/home/$USER/Desktop/QC_CPU.desktop"
cp "/home/$USER/Desktop/QC/QC_GPU.desktop" "/home/$USER/Desktop/QC_GPU.desktop"

sed -i "s/USERNAME/$USER/g" "/home/$USER/Desktop/QC_CPU.desktop"
sed -i "s/USERNAME/$USER/g" "/home/$USER/Desktop/QC_GPU.desktop"

chmod u+x /home/$USER/QC/run_QC_CPU.sh
chmod u+x /home/$USER/QC/run_QC_GPU.sh
chmod u+x /home/$USER/Desktop/QC_CPU.desktop
chmod u+x /home/$USER/Desktop/QC_GPU.desktop

sudo apt-get install x11-xserver-utils
xhost +

echo "Installation Completed."
echo "Enjoy!"
echo "Biomedical Research Imaging Center (BRIC),  Univerisity of North Carolina at Chapel Hill (UNC-CH)."
