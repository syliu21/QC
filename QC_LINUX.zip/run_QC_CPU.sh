#!/bin/bash -l
xhost +
echo running QC script
res=`docker ps`
strQC="QC_CPU"
if [[ $res == *$strQC* ]]
then
echo stop old docker session
docker stop QC_CPU
echo start new docker session
docker start QC_CPU
else
echo start new docker session
docker start QC_CPU
fi
echo entering docker
docker exec -it QC_CPU /bin/bash /home/run_QC/run_QC.sh
